package com.example.gym3day

import android.content.Context
import java.time.LocalDate

class Store(context: Context) {
    private val p = context.getSharedPreferences("gym3day", Context.MODE_PRIVATE)

    var level: Level
        get() = runCatching { Level.valueOf(p.getString("level", Level.BEGINNER.name)!!) }
            .getOrDefault(Level.BEGINNER)
        set(value) = p.edit().putString("level", value.name).apply()

    fun weight(exerciseId: String): String = p.getString("w_$exerciseId", "") ?: ""
    fun setWeight(exerciseId: String, value: String) =
        p.edit().putString("w_$exerciseId", value).apply()

    fun lastDone(dayId: String): LocalDate? =
        p.getLong("d_$dayId", -1L).takeIf { it >= 0 }?.let { LocalDate.ofEpochDay(it) }

    fun count(dayId: String): Int = p.getInt("c_$dayId", 0)

    fun markDone(dayId: String) {
        p.edit()
            .putLong("d_$dayId", LocalDate.now().toEpochDay())
            .putInt("c_$dayId", count(dayId) + 1)
            .apply()
    }
}
