package com.example.gym3day

import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.time.format.DateTimeFormatter

private val dateFmt = DateTimeFormatter.ofPattern("d MMM yyyy")

// ---------------- Home ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    level: Level,
    onLevel: (Level) -> Unit,
    store: Store,
    onOpen: (WorkoutDay) -> Unit,
) {
    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("Gym 3-Day Plan") }) }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { Text("Your level", style = MaterialTheme.typography.titleMedium) }
            item {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Level.entries.forEach { l ->
                        FilterChip(
                            selected = l == level,
                            onClick = { onLevel(l) },
                            label = { Text(l.label) },
                        )
                    }
                }
            }
            item {
                Text(
                    "${level.sets} sets of ${level.reps} reps, rest ${level.restSec} s",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            item {
                InfoCard(
                    "Weekly schedule",
                    "Train 3 non-consecutive days, e.g. Sunday, Tuesday, Thursday. Walk or rest on the other days.",
                )
            }
            items(Plan.days, key = { it.id }) { day ->
                DayCard(day, store) { onOpen(day) }
            }
            item {
                InfoCard(
                    "How to progress",
                    "When you finish every set at the top of the rep range with good form, add 2.5–5 kg next session.",
                )
            }
        }
    }
}

@Composable
private fun DayCard(day: WorkoutDay, store: Store, onClick: () -> Unit) {
    val last = store.lastDone(day.id)
    ElevatedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(day.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(day.focus, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(4.dp))
            Text(
                day.exercises.joinToString(", ") { it.name },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                if (last == null) "Not done yet"
                else "Last: ${last.format(dateFmt)}  (${store.count(day.id)} total)",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(body, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

// ---------------- Workout ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkoutScreen(
    day: WorkoutDay,
    level: Level,
    store: Store,
    onBack: () -> Unit,
    onFinish: () -> Unit,
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val done = remember { mutableStateMapOf<String, Boolean>() }

    var restLeft by remember { mutableIntStateOf(0) }
    var restRun by remember { mutableIntStateOf(0) }
    var restCounter by remember { mutableIntStateOf(0) }

    LaunchedEffect(restRun) {
        if (restRun == 0) return@LaunchedEffect
        restLeft = level.restSec
        while (restLeft > 0) {
            delay(1000)
            restLeft--
        }
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    val totalSets = day.exercises.size * level.sets
    val doneCount = done.values.count { it }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(day.title)
                        Text(day.focus, style = MaterialTheme.typography.bodySmall)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Column(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp)
                ) {
                    LinearProgressIndicator(
                        progress = { doneCount.toFloat() / totalSets },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (restLeft > 0) "Rest ${restLeft} s" else "$doneCount / $totalSets sets",
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.titleMedium,
                        )
                        if (restLeft > 0) {
                            TextButton(onClick = { restRun = 0; restLeft = 0 }) { Text("Skip rest") }
                        }
                        Button(
                            onClick = {
                                store.markDone(day.id)
                                Toast.makeText(context, "Workout saved", Toast.LENGTH_SHORT).show()
                                onFinish()
                            },
                            enabled = doneCount > 0,
                        ) { Text("Finish workout") }
                    }
                }
            }
        },
    ) { pad ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                InfoCard("Warm-up, 5–8 min", "Light cardio, then 1–2 light sets of the first exercise.")
            }
            items(day.exercises, key = { it.id }) { ex ->
                ExerciseCard(ex, level, store, done) { checked ->
                    if (checked) {
                        restCounter += 1
                        restRun = restCounter
                    }
                }
            }
            item { InfoCard("Finisher", day.finisher) }
        }
    }
}

@Composable
private fun ExerciseCard(
    ex: Exercise,
    level: Level,
    store: Store,
    done: SnapshotStateMap<String, Boolean>,
    onSetToggled: (Boolean) -> Unit,
) {
    var weight by remember(ex.id) { mutableStateOf(store.weight(ex.id)) }
    var showTip by remember { mutableStateOf(false) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(ex.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(
                        ex.muscles,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                TextButton(onClick = { showTip = !showTip }) {
                    Text(if (showTip) "Hide form tip" else "Form tip")
                }
            }

            val target = if (ex.timed) "${level.sets} × ${level.holdSec} s" else "${level.sets} × ${level.reps}"
            Text("Target: $target", style = MaterialTheme.typography.bodyMedium)

            if (level == Level.BEGINNER && ex.beginnerAlt != null) {
                Text(
                    "Beginner option: ${ex.beginnerAlt}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            if (showTip) {
                Text(ex.tip, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
            }

            if (ex.weighted) {
                OutlinedTextField(
                    value = weight,
                    onValueChange = { v ->
                        weight = v.filter { it.isDigit() || it == '.' }.take(6)
                        store.setWeight(ex.id, weight)
                    },
                    label = { Text("Load (kg)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.padding(top = 8.dp).fillMaxWidth(),
                )
            }

            Row(
                Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                repeat(level.sets) { i ->
                    val key = "${ex.id}_$i"
                    val checked = done[key] == true
                    val icon: (@Composable () -> Unit)? =
                        if (checked) {
                            { Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp)) }
                        } else null
                    FilterChip(
                        selected = checked,
                        onClick = {
                            done[key] = !checked
                            onSetToggled(!checked)
                        },
                        label = { Text("Set ${i + 1}") },
                        leadingIcon = icon,
                    )
                }
            }
        }
    }
}
