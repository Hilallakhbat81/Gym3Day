package com.example.gym3day

enum class Level(
    val label: String,
    val sets: Int,
    val reps: String,
    val restSec: Int,
    val holdSec: Int,
) {
    BEGINNER("Beginner", 2, "12–15", 60, 30),
    INTERMEDIATE("Intermediate", 3, "10–12", 75, 45),
    ADVANCED("Advanced", 4, "8–10", 90, 60),
}

data class Exercise(
    val id: String,
    val name: String,
    val muscles: String,
    val tip: String,
    val timed: Boolean = false,
    val weighted: Boolean = true,
    val beginnerAlt: String? = null,
)

data class WorkoutDay(
    val id: String,
    val title: String,
    val focus: String,
    val exercises: List<Exercise>,
    val finisher: String,
)

object Plan {
    val days = listOf(
        WorkoutDay(
            id = "A", title = "Day A", focus = "Full body: squat & push",
            exercises = listOf(
                Exercise("a_squat", "Barbell Back Squat", "Quads, glutes, core",
                    "Feet shoulder-width, chest up. Sit back until thighs are parallel, drive through heels.",
                    beginnerAlt = "Goblet Squat (dumbbell)"),
                Exercise("a_bench", "Bench Press", "Chest, triceps, front shoulders",
                    "Pinch shoulder blades, lower bar to mid-chest, elbows about 45°.",
                    beginnerAlt = "Dumbbell Bench Press"),
                Exercise("a_pulldown", "Lat Pulldown", "Lats, biceps",
                    "Pull bar to upper chest, slight lean back, control the way up."),
                Exercise("a_ohp", "Dumbbell Shoulder Press", "Shoulders, triceps",
                    "Brace core, press overhead without arching the lower back.",
                    beginnerAlt = "Seated Dumbbell Press"),
                Exercise("a_plank", "Plank", "Core",
                    "Straight line head to heels, squeeze glutes, keep breathing.",
                    timed = true, weighted = false),
            ),
            finisher = "10 min incline walk or bike at a moderate pace.",
        ),
        WorkoutDay(
            id = "B", title = "Day B", focus = "Full body: hinge & pull",
            exercises = listOf(
                Exercise("b_rdl", "Romanian Deadlift", "Hamstrings, glutes, lower back",
                    "Push hips back, soft knees, neutral spine, keep the bar close to your legs.",
                    beginnerAlt = "Dumbbell RDL"),
                Exercise("b_row", "Seated Cable Row", "Mid-back, lats, biceps",
                    "Sit tall, pull handle to belly, squeeze shoulder blades together."),
                Exercise("b_incline", "Incline Dumbbell Press", "Upper chest, shoulders",
                    "Bench at 30°, lower dumbbells to chest level with control."),
                Exercise("b_lunge", "Walking Lunges (reps per leg)", "Quads, glutes",
                    "Long step, back knee close to the floor, front knee tracks over toes.",
                    beginnerAlt = "Bodyweight Reverse Lunges"),
                Exercise("b_deadbug", "Dead Bug", "Core",
                    "Lower back pressed to the floor, extend opposite arm and leg slowly.",
                    weighted = false),
            ),
            finisher = "8–10 min rowing machine, easy to moderate.",
        ),
        WorkoutDay(
            id = "C", title = "Day C", focus = "Full body: machines & conditioning",
            exercises = listOf(
                Exercise("c_legpress", "Leg Press", "Quads, glutes",
                    "Feet mid-platform, lower until knees reach ~90°, don't lock knees."),
                Exercise("c_pullup", "Pull-Ups", "Lats, biceps, grip",
                    "Full hang to chin over bar. On the assisted machine, log the assist weight.",
                    beginnerAlt = "Assisted Pull-Up Machine"),
                Exercise("c_pushup", "Push-Ups", "Chest, triceps, core",
                    "Body in a straight line, chest to just above the floor.",
                    weighted = false, beginnerAlt = "Incline Push-Ups (hands on bench)"),
                Exercise("c_facepull", "Cable Face Pull", "Rear shoulders, upper back",
                    "Rope at face height, pull toward eyes, elbows high and wide."),
                Exercise("c_carry", "Farmer's Carry", "Grip, traps, core",
                    "Heavy dumbbells, tall posture, short quick steps.",
                    timed = true),
            ),
            finisher = "Intervals: 6 rounds of 30 s hard / 60 s easy on bike or treadmill.",
        ),
    )
}
