package com.example.gym3day

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val store = Store(this)
        setContent { GymTheme { App(store) } }
    }
}

@Composable
fun App(store: Store) {
    var level by remember { mutableStateOf(store.level) }
    var openDayId by rememberSaveable { mutableStateOf<String?>(null) }
    val day = Plan.days.firstOrNull { it.id == openDayId }

    if (day == null) {
        HomeScreen(
            level = level,
            onLevel = { level = it; store.level = it },
            store = store,
            onOpen = { openDayId = it.id },
        )
    } else {
        BackHandler { openDayId = null }
        WorkoutScreen(
            day = day, level = level, store = store,
            onBack = { openDayId = null },
            onFinish = { openDayId = null },
        )
    }
}
