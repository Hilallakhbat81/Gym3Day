# Gym 3-Day (Android, Kotlin + Jetpack Compose)

## Open & run
1. Android Studio (Koala or newer) -> File > Open -> select this `Gym3Day` folder.
2. Let Gradle sync (downloads Gradle 8.9 / AGP 8.5.2 / Kotlin 2.0.20).
3. Plug in phone (USB debugging on) or start an emulator -> Run.

## Features
- 3 full-body days (A/B/C), levels: Beginner / Intermediate / Advanced
- Set checkboxes, auto rest timer with vibration, load (kg) saved per exercise
- Last-done date and session count per day (stored on device)

## Edit the plan
`app/src/main/java/com/example/gym3day/WorkoutData.kt`
